package ServletClasses;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import DatabaseConnection.AddQuestionBtech;
import DatabaseConnection.AddQuestionMBA;
import DatabaseConnection.AddQuestionPoly;
import DatabaseConnection.CheckingValidity;
import DatabaseConnection.InputExam;
import DatabaseConnection.Result;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class GetAns extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
    public GetAns() {
    }
   static  int itemp;
//    public void init(ServletConfig config) throws ServletException {
//		
//	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		HttpSession hs=request.getSession();
		String name=(String)hs.getAttribute("name");
		String course=(String)hs.getAttribute("course");
		int id=(Integer)hs.getAttribute("userid");
		CheckingValidity cv=new CheckingValidity();
		
		int size=Integer.parseInt(request.getParameter("size"));
		String finish=request.getParameter("finish");
		if(finish==null)
			finish="";
			if(("fin").equals(finish))
		{
			Result r=new Result();
			
			r.setRoll(id);
			r.setName(name);
			r.setCourse(course);
			r.setMarks(0);
			r.setNo_of_oqestion(0);
			r.setTotalMarsk(0);
			r.setAction("fail");
			r.setItemp(itemp);
			cv.addResult(r);
			
			
			PrintWriter out=response.getWriter();
			out.println(""
					+ "<h1>SuccessFuly Submit...</h1>");
			hs.invalidate();
			RequestDispatcher rd=request.getRequestDispatcher("index.html");
			rd.forward(request, response);
		}
		
		
		for(int i=0;i<size;i++)
		{
			String ans=request.getParameter("ans"+i);
			String ques=request.getParameter("question"+i);
			int qid=Integer.parseInt(request.getParameter("qid"+i));
			InputExam te=new InputExam();
			
			te.setQid(qid);
			te.setQuestion(ques);
			te.setAnswere(ans);
			te.setRoll(id);
			cv.addInput(te);
			
			System.out.println("hii");
			
		}
		
		
		List<InputExam> list_Input=cv.getInputExam();
		List<AddQuestionBtech> list1=null;
		List<AddQuestionPoly> list2=null;
		List<AddQuestionMBA> list3=null;
		int j=-1;
		if(course.equals("B.Tech"))
		{
		list1=cv.getListBtech();

		j=1;
		}
		else if(course.equals("Polytechnic"))
		{

		list2=cv.getListPoly();

		j=2;
		}
		else if(course.equals("MBA"))
		{

		list3=cv.getListMBA();

		j=3;
		}
		int mask=0;
		int total=0;
		int count_ques=0;
		if(j==1)
		{
			mask=0;
			total=0;
			count_ques=0;
			itemp++;
			int x=0;
			for(int i=list_Input.size()-list1.size();i<list_Input.size();i++)
			{
			 	if(list_Input.get(i).getRoll()==id&&list_Input.get(i).getQid()==list1.get(x).getId()&&list_Input.get(i).getAnswere().equals(list1.get(x).getC_Ans1()))
				{
					mask+=list1.get(x).getMask();
				}
				total+=list1.get(x).getMask();
				count_ques++;
				if(x==list1.size()-1)
					x=0;
				x++;
				
				
				
				
			}
		}
		else if(j==2)
		{
			 mask=0;
			 total=0;
			count_ques=0;
			itemp++;
			int x=0;
			for(int i=list_Input.size()-list2.size();i<list_Input.size();i++)
			{
				if(list_Input.get(i).getRoll()==id&&list_Input.get(i).getQid()==list2.get(x).getId()&&list_Input.get(i).getAnswere().equals(list2.get(x).getC_Ans1()))
				{
					mask+=list2.get(x).getMask();
				}
				total+=list2.get(x).getMask();
				count_ques++;
				if(x==list2.size()-1)
					x=0;
				x++;
				
				
				
				
			}
		}
		else if(j==3)
		{
			mask=0;
			total=0;
			count_ques=0;
			itemp++;
			int x=0;
			for(int i=list_Input.size()-list3.size();i<list_Input.size();i++)
			{
				if(list_Input.get(i).getRoll()==id&&list_Input.get(i).getQid()==list3.get(x).getId()&&list_Input.get(i).getAnswere().equals(list3.get(x).getC_Ans1()))
				{
					mask+=list3.get(x).getMask();
				}
				total+=list3.get(x).getMask();
				count_ques++;
				if(x==list3.size()-1)
					x=0;
				x++;
				
				
				
				
			}
		}
		else 
		{total=1;
		}
		String action="";
		if(mask*100/total>60)
		{
			action="First";
		}
		else if(mask*100/total<60&&mask*100/total>50)
		{
			action="Second";
		}
		else if(mask*100/total<50&&mask*100/total>=34)
		{
			action="Third";
		}
		else 
		{
			action="Fail";
		}
		
		Result r=new Result();
		
		r.setRoll(id);
		r.setName(name);
		r.setCourse(course);
		r.setMarks(mask);
		r.setNo_of_oqestion(count_ques);
		r.setTotalMarsk(total);
		r.setAction(action);
		r.setItemp(itemp);
		cv.addResult(r);
		
		
		PrintWriter out=response.getWriter();
		out.println(""
				+ "<h1>SuccessFuly Submit...</h1>");
		hs.invalidate();
		RequestDispatcher rd=request.getRequestDispatcher("index.html");
		rd.forward(request, response);
		
		}
		 catch(Exception e){
			 RequestDispatcher rd=request.getRequestDispatcher("instruction.html");
				rd.forward(request, response);
				
				
				
			}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
