package DatabaseConnection;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;


public class BuildConnection {
		
		private String userName;

		public static void main(String[] args) {

		}

		public  LoginInfo getUser(int id) {
			LoginInfo us = null;

			try {
				Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(LoginInfo.class);
				ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties())
						.buildServiceRegistry();
				SessionFactory sf = con.buildSessionFactory(reg);
				Session session = sf.openSession();
				Transaction tx = session.beginTransaction();
				us = (LoginInfo) session.get(LoginInfo.class, id);
				tx.commit();
				session.close();
				sf.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			return us;
		}
		public  AdminLogin getAdmin(int id) {
			AdminLogin us = null;

			try {
				Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(AdminLogin.class);
				ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties())
						.buildServiceRegistry();
				SessionFactory sf = con.buildSessionFactory(reg);
				Session session = sf.openSession();
				Transaction tx = session.beginTransaction();
				us = (AdminLogin) session.get(AdminLogin.class, id);
				tx.commit();
				session.close();
				sf.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
			return us;
		}
		public  int checkUser(int id, String password) {
			LoginInfo user = getUser(id);
			boolean flag;
			if (user == null)
				return -1;
			flag = user.getPassword().equals(password);
			if(flag)
				setUserName(user.getUserName());
			if(flag)
				return user.getId();
			return -1;
				
				
		}
		public  boolean checkAdmin(int id, String password) {
			AdminLogin user = getAdmin(id);
			boolean flag=false;
			if (user == null)
				return flag;
			flag = user.getPassword().equals(password);
			if(flag)
				setUserName(user.getUserName());
			
			return flag;
				
				
		}
		
		public  String getUserName() {
			return this.userName;
		}

		public void setUserName(String userName) {
			this.userName = userName;
		}
	}

	

