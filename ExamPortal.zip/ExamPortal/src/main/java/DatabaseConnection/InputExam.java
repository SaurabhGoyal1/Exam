package DatabaseConnection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class InputExam {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	private int qid;
	private String question;
	private String answere;
	private int roll;
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	public int getid() {
		return id;
	}
	public int getQid() {
		return qid;
	}
	public void setQid(int qid) {
		this.qid = qid;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getAnswere() {
		return answere;
	}
	public void setAnswere(String answere) {
		this.answere = answere;
	}
	
	
	
	
	
	
}
