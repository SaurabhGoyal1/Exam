package ServletClasses;

import java.io.IOException;
import DatabaseConnection.CheckingValidity;
import DatabaseConnection.RegisterInfo;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
    public RegisterServlet() {
        
    }
    public static int i;
  
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		String userName=request.getParameter("email");
		String password=request.getParameter("psw");
		String pass_re=request.getParameter("psw-repeat");
		String course=request.getParameter("sel");
		RegisterInfo ri=new RegisterInfo();
		if(userName!=null)
			ri.setUserName(userName);
		if(password!=null&&pass_re!=null&&password.equals(pass_re))
			ri.setPassword(password);
		if(course!=null)
			ri.setCourse(course);
		
		
		CheckingValidity cv=new CheckingValidity();
		if(cv.addData(ri))
		{
			if(cv.loginAddInfo(ri))
			{
				RequestDispatcher rd=request.getRequestDispatcher("login.html");
				rd.include(request, response);
			}
		}
		else
			{RequestDispatcher rd=request.getRequestDispatcher("register.html");
		rd.include(request, response);
			}
			
			
		}
		 catch(Exception e){
			 RequestDispatcher rd=request.getRequestDispatcher("instruction.html");
				rd.forward(request, response);
				
				
				
			}
		
		
		
		
	}

}
