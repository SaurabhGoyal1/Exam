package DatabaseConnection;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Result {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private int roll;
	private int no_of_oqestion;
	private int marks;
	private String name;
	private String course;
	private String action;
	private int totalMarsk;
	private int itemp;
	public int getItemp() {
		return itemp;
	}

	public void setItemp(int itemp) {
		this.itemp = itemp;
	}

	public int getTotalMarsk() {
		return totalMarsk;
	}

	public void setTotalMarsk(int totalMarsk) {
		this.totalMarsk = totalMarsk;
	}

	public int getId() {
		return id;
	}
	
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	public int getNo_of_oqestion() {
		return no_of_oqestion;
	}
	public void setNo_of_oqestion(int no_of_oqestion) {
		this.no_of_oqestion = no_of_oqestion;
	}
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCourse() {
		return course;
	}
	public void setCourse(String course) {
		this.course = course;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	
	

}
