package DatabaseConnection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class AddQuestionBtech {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	private String question;
	private String c_Ans1;
	private String w_Ans2;
	private String w_Ans3;
	private String w_Ans4;
	private int mask;
	private int adminId;
	private int testId;
	public int getTestId() {
		return testId;
	}
	public void setTestId(int testId) {
		this.testId = testId;
	}
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public int getMask() {
		return mask;
	}
	public void setMask(int mask) {
		this.mask = mask;
	}
	public int getId() {
		return id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getC_Ans1() {
		return c_Ans1;
	}
	public void setC_Ans1(String c_Ans1) {
		this.c_Ans1 = c_Ans1;
	}
	public String getW_Ans2() {
		return w_Ans2;
	}
	public void setW_Ans2(String w_Ans2) {
		this.w_Ans2 = w_Ans2;
	}
	public String getW_Ans3() {
		return w_Ans3;
	}
	public void setW_Ans3(String w_Ans3) {
		this.w_Ans3 = w_Ans3;
	}
	public String getW_Ans4() {
		return w_Ans4;
	}
	public void setW_Ans4(String w_Ans4) {
		this.w_Ans4 = w_Ans4;
	}
	
	

}
