package DatabaseConnection;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

public class CheckingValidity {
	Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(RegisterInfo.class);
	ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
	SessionFactory sf = con.buildSessionFactory(reg);
	Session session = sf.openSession();
	Transaction tx = session.beginTransaction();
	
	   
	public static void main(String[] args)
	{
		
	}
	
	public boolean addData(RegisterInfo ri) {
		RegisterInfo item=null;
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(RegisterInfo.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
		try {
		    item =new  RegisterInfo();

		    
			item.setUserName(ri.getUserName());
			
			item.setPassword(ri.getPassword());
			
			item.setCourse(ri.getCourse());
			
		    session.save(item);
		    
            tx.commit();
            return true;
		}
		catch(IllegalArgumentException e) {
			session.save(ri);
			tx.commit();
		}catch(NullPointerException e) {
			session.save(ri);
			tx.commit();
		}
		return false;
		
		
	}
	public boolean loginAddInfo(RegisterInfo rf)
	{Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(LoginInfo.class);
	ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
	SessionFactory sf = con.buildSessionFactory(reg);
	Session session = sf.openSession();
	Transaction tx = session.beginTransaction();
		try{
		LoginInfo lf=new LoginInfo();
		
		lf.setUserName(rf.getUserName());
		lf.setPassword(rf.getPassword());
		session.save(lf);
        tx.commit();
        return true;
		}
        catch(IllegalArgumentException e) {
			session.save(rf);
			tx.commit();
		}catch(NullPointerException e) {
			session.save(rf);
			tx.commit();
		}
        return false;
	}
	public String validity(int id)
	{
		
		RegisterInfo item= (RegisterInfo) session.get(RegisterInfo.class, id);
		if(item!=null)
		{
			return item.getCourse();
		}
		return null;
		
	}
	public boolean addQuestionBtech(AddQuestionBtech rf)
	{
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(AddQuestionBtech.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
			try{
			session.save(rf);
	        tx.commit();
	        return true;
			}
	        catch(IllegalArgumentException e) {
				session.save(rf);
				tx.commit();
			}catch(NullPointerException e) {
				session.save(rf);
				tx.commit();
			}
	        return false;			
	}
	public boolean addQuestionMBA(AddQuestionMBA rf)
	{
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(AddQuestionMBA.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
			try{
			session.save(rf);
	        tx.commit();
	        return true;
			}
	        catch(IllegalArgumentException e) {
				session.save(rf);
				tx.commit();
			}catch(NullPointerException e) {
				session.save(rf);
				tx.commit();
			}
	        return false;			
	}
	public boolean addQuestionPoly(AddQuestionPoly rf)
	{
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(AddQuestionPoly.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
			try{
			session.save(rf);
	        tx.commit();
	        return true;
			}
	        catch(IllegalArgumentException e) {
				session.save(rf);
				tx.commit();
			}catch(NullPointerException e) {
				session.save(rf);
				tx.commit();
			}
	        return false;			
	}
	public void addInput(InputExam rf)
	{
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(InputExam.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
			try{
			session.save(rf);
	        tx.commit();
	        
			}
	        catch(IllegalArgumentException e) {
				session.save(rf);
				tx.commit();
			}catch(NullPointerException e) {
				session.save(rf);
				tx.commit();
			}
	        		
	}
	public boolean addAdmin(AllAdmin rf)
	{
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(AllAdmin.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
			try{
			session.save(rf);
	        tx.commit();
	        return true;
	        
			}
	        catch(IllegalArgumentException e) {
				session.save(rf);
				tx.commit();
			}catch(NullPointerException e) {
				session.save(rf);
				tx.commit();
			}
	        	return false;	
	}
	public boolean addResult(Result rf)
	{
		Configuration con = new Configuration().configure("hibernate.cfg.xml").addAnnotatedClass(AllAdmin.class);
		ServiceRegistry reg = new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
		SessionFactory sf = con.buildSessionFactory(reg);
		Session session = sf.openSession();
		Transaction tx = session.beginTransaction();
			try{
			session.save(rf);
	        tx.commit();
	        return true;
	        
			}
	        catch(IllegalArgumentException e) {
				session.save(rf);
				tx.commit();
			}catch(NullPointerException e) {
				session.save(rf);
				tx.commit();
			}
	        	return false;	
	}
	public List<Result> getListResult(){
		Query q = (Query) session.createQuery("from Result");
		
		@SuppressWarnings("unchecked")
		List<Result> lst = (List<Result>) ((org.hibernate.Query) q).list();
		return  lst;
	}
	public List<InputExam> getInputExam(){
		Query q = (Query) session.createQuery("from InputExam");
		
		@SuppressWarnings("unchecked")
		List<InputExam> lst = (List<InputExam>) ((org.hibernate.Query) q).list();
		return  lst;
	}
	public List<AdminLogin> getAdminList(){
		Query q = (Query) session.createQuery("from AdminLogin");
		
		@SuppressWarnings("unchecked")
		List<AdminLogin> lst = (List<AdminLogin>) ((org.hibernate.Query) q).list();
		return  lst;
	}
	public RegisterInfo getRegisSess(int id)
	{
		RegisterInfo item= (RegisterInfo) session.get(RegisterInfo.class, id);
		return item;
	}
	public List<LoginInfo> getListLogin(){
		Query q = (Query) session.createQuery("from LoginInfo");
		
		@SuppressWarnings("unchecked")
		List<LoginInfo> lst = (List<LoginInfo>) ((org.hibernate.Query) q).list();
		return  lst;
	}
	public List<AddQuestionBtech> getListBtech(){
		Query q = (Query) session.createQuery("from AddQuestionBtech");
		
		@SuppressWarnings("unchecked")
		List<AddQuestionBtech> lst = (List<AddQuestionBtech>) ((org.hibernate.Query) q).list();
		return  lst;
	}
	public List<AddQuestionPoly> getListPoly(){
		Query q = (Query) session.createQuery("from AddQuestionPoly");
		
		@SuppressWarnings("unchecked")
		List<AddQuestionPoly> lst = (List<AddQuestionPoly>) ((org.hibernate.Query) q).list();
		return  lst;
	}
	public List<RegisterInfo> getListRegister(){
		Query q = (Query) session.createQuery("from RegisterInfo");
		
		@SuppressWarnings("unchecked")
		List<RegisterInfo> lst = (List<RegisterInfo>) ((org.hibernate.Query) q).list();
		return  lst;
	}
	public List<AddQuestionMBA> getListMBA(){
		Query q = (Query) session.createQuery("from AddQuestionMBA");
		
		@SuppressWarnings("unchecked")
		List<AddQuestionMBA> lst = (List<AddQuestionMBA>) ((org.hibernate.Query) q).list();
		return  lst;
	}
	public List<AllAdmin> getListAllAdmin(){
		Query q = (Query) session.createQuery("from AllAdmin");
		
		@SuppressWarnings("unchecked")
		List<AllAdmin> lst = (List<AllAdmin>) ((org.hibernate.Query) q).list();
		return  lst;
	}
}
