package ServletClasses;

import java.io.IOException;
import DatabaseConnection.AddQuestionBtech;
import DatabaseConnection.AddQuestionMBA;
import DatabaseConnection.AddQuestionPoly;
import DatabaseConnection.CheckingValidity;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class QuestionBtechServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
    public QuestionBtechServlet() {
        
    }
    public static int i=0;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		HttpSession hs = request.getSession();
		
	int id=(Integer)hs.getAttribute("id");
	int testId=(Integer)hs.getAttribute("testId");
	String course=(String)hs.getAttribute("course");
	String name=(String)hs.getAttribute("name");
	
		
		
		String question=request.getParameter("question");
		String c_ans1=request.getParameter("c_ans1");
		String w_ans2=request.getParameter("w_ans2");
		String w_ans3=request.getParameter("w_ans3");
		String w_ans4=request.getParameter("w_ans4");
		int mask=Integer.parseInt(request.getParameter("mask"));
		CheckingValidity cv=new CheckingValidity();
		boolean flag=false;
		if(course.equals("B.Tech")&&name!=null)
		{
		AddQuestionBtech aq=new AddQuestionBtech();
		aq.setQuestion(question);
		aq.setC_Ans1(c_ans1);
		aq.setW_Ans2(w_ans2);
		aq.setW_Ans3(w_ans3);
		aq.setW_Ans4(w_ans4);
		aq.setMask(mask);
		aq.setAdminId(id);	
		aq.setTestId(testId);
		flag=cv.addQuestionBtech(aq);
		
		}
		else if(course.equals("MBA")&&name!=null)
		{
			AddQuestionMBA aq=new AddQuestionMBA();
			aq.setQuestion(question);
			aq.setC_Ans1(c_ans1);
			aq.setW_Ans2(w_ans2);
			aq.setW_Ans3(w_ans3);
			aq.setW_Ans4(w_ans4);
			aq.setMask(mask);
			aq.setAdminId(id);
			aq.setTestId(testId);
			
			flag=cv.addQuestionMBA(aq);
		}
		else if(course.equals("Poly")&&name!=null)
		{
		AddQuestionPoly aq=new AddQuestionPoly();
		aq.setQuestion(question);
		aq.setC_Ans1(c_ans1);
		aq.setW_Ans2(w_ans2);
		aq.setW_Ans3(w_ans3);
		aq.setW_Ans4(w_ans4);
		aq.setMask(mask);
		aq.setAdminId(id);
		aq.setTestId(testId);
		
		flag=cv.addQuestionPoly(aq);
		}
		
		
		if(flag)
		{
			String m="Add Successfully...";
			
			RequestDispatcher rd=request.getRequestDispatcher("addQuestion.jsp?&mess="+m);
			rd.forward(request, response);
		}
		else
		{String m="try again...";
			
			RequestDispatcher rd=request.getRequestDispatcher("addQuestion.jsp?&mess="+m);
			rd.forward(request, response);
		}
		
		
		
		}
		 catch(Exception e){
			 RequestDispatcher rd=request.getRequestDispatcher("instruction.html");
				rd.forward(request, response);
				
				
				
			}
		
		
		
		
	}

}
