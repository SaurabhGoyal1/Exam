package ServletClasses;

import java.io.IOException;

import DatabaseConnection.BuildConnection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
    public AdminLoginServlet() {
       
    }

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String str=request.getParameter("email");
		
		if(str!=null)
		{
		int id=Integer.parseInt(str);
		String pass=request.getParameter("password");
		
		
		
		BuildConnection ob = new BuildConnection();
		
		//System.out.println(id);
		if(ob.checkAdmin(id, pass)) {
				RequestDispatcher rd=request.getRequestDispatcher("courses.jsp?id="+id);
				rd.forward(request, response);
			}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("loginAdmin.jsp");
			rd.include(request, response);
		}
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("loginAdmin.html");
			rd.include(request, response);
		}
		
		
	}

}
