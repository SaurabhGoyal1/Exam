package ServletClasses;

import java.io.IOException;

import DatabaseConnection.BuildConnection;
import DatabaseConnection.CheckingValidity;
import DatabaseConnection.RegisterInfo;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

   
    public LoginServlet() {
       
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
		String str=request.getParameter("email");
		if(str!=null)
		{
		int id=Integer.parseInt(str);
		String pass=request.getParameter("password");
		
		
		CheckingValidity cv=new CheckingValidity();
		BuildConnection ob = new BuildConnection();
		ob.checkUser(id, pass);
		
		 HttpSession hs = request.getSession();
		 hs.setAttribute("userid",id);
		
		
		
		if(id!=0)
		{
			RegisterInfo item=cv.getRegisSess(id);
			hs.setAttribute("name",item.getUserName().subSequence(0,7));
			 
			if(item!=null&&item.getCourse().equals("B.Tech"))
			{hs.setAttribute("course",item.getCourse());
				RequestDispatcher rd=request.getRequestDispatcher("studentpage.jsp");
				rd.forward(request, response);
			}
			else if(item!=null&&item.getCourse().equals("Polytechnic"))
			{hs.setAttribute("course",item.getCourse());
				RequestDispatcher rd=request.getRequestDispatcher("studentpage.jsp");
				rd.forward(request, response);
			}
			else if(item!=null&&item.getCourse().equals("MBA"))
			{hs.setAttribute("course",item.getCourse());
				RequestDispatcher rd=request.getRequestDispatcher("studentpage.jsp");
				rd.forward(request, response);
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("login.html");
				rd.include(request, response);
			}
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.include(request, response);
		}
		}
		else
		{
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.include(request, response);
		}
		}
	 catch(Exception e){
		 RequestDispatcher rd=request.getRequestDispatcher("instruction.html");
			rd.forward(request, response);
			
			
			
		}
		
		
		
		
		
		
	}

}
